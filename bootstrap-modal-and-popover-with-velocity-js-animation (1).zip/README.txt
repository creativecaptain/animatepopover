A Pen created at CodePen.io. You can find this one at http://codepen.io/zeasts/pen/mPLEQe.

 

Forked from [Mike Sozanski](http://codepen.io/macsupport/)'s Pen [Bootstrap Modal and popover with Velocity.js animation](http://codepen.io/macsupport/pen/OPwvwx/).